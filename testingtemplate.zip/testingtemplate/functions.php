<?php

add_theme_support('editor-styles');
add_editor_style('style.css');